# Kristal v8 — normalization report

This is the corrected **full static v8 normalization** of the 123-domain collection. Original source artifacts are preserved byte-for-byte; the new `.kristal/v8/` layer is derived and rebuildable.

## Validation result

- Domains: **123/123**.
- Strict portable `kristal_state/6.0` schema: **123/123**.
- Official Kristal JS `verifyKristalState(requireIdentity=true)`: **123/123**.
- v8 lexicon: **123/123**.
- v8 lexicon stack: **123/123**.
- v8 rebuildable query-index manifest: **123/123**.
- Query index content hashes: **123/123**.
- Icon profile schema: **123/123**.
- Windows ICO 10-size set: **123/123**.
- `desktop.ini`: **123/123**.
- Original files byte-preserved: **7008/7008**.

## Static v8 package definition

Each domain now contains:

- `.kristal/v8/portable-state.kristal-state.json` — strict v6 portable semantic substrate with recomputed canonical identity;
- `.kristal/v8/projection-manifest.json` — exact source hash, adapter path and normalization changes;
- `.kristal/v8/lexicon-fr.json` — normative v8 lexical companion;
- `.kristal/v8/lexicon-stack-fr.json` — deterministic v8 lexical stack;
- `.kristal/v8/query-index.json` and `.kristal/v8/index/*.json` — real derived query indexes;
- `.kristal/v8/package.json` — package linkage descriptor;
- `.kristal/icon-profile.json`, multi-resolution `.ico`, and `desktop.ini` — presentation layer.

## Important conformance boundary

**123/123 are v8-normalized static packages. This is not a claim that a static ZIP itself satisfies `V8-Full` runtime conformance.** V8-Full includes runtime Reader, Language, Query, Federation, AI Context and Integrity behavior.

## Source families

| Source | Count |
|---|---:|
| `kristal_state/6.0` | 110 |
| `semantic_corpus/1.0` | 1 |
| `source_package/None` | 1 |
| `structured_epistemic_state/5.0` | 11 |

## Conversion paths

| Path | Count |
|---|---:|
| `semantic_corpus_to_v6` | 1 |
| `source_package_to_v6` | 1 |
| `structured_epistemic_state_to_v6` | 11 |
| `v6_normalization` | 110 |

## Lexical layer

- Explicit French terms resolved: **15,531**.
- Semantic identifiers intentionally marked `missing`: **20,800**.
- Missing means no explicit French lexical authority was found; the normalizer does not invent a term.

## Domains requiring semantic-envelope adaptation

- `Kristal-Bible` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-Biodiversity` — kristal_state/6.0 via `v6_normalization`; 32 record-role mappings
- `Kristal-Catho` — semantic_corpus/1.0 via `semantic_corpus_to_v6`
- `Kristal-FoodBrands` — source_package/None via `source_package_to_v6`
- `Kristal-HistoryTech` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-HomeCare` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-HospitalOps` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-HumanBody` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-Math` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-MechanicalEngineering` — kristal_state/6.0 via `v6_normalization`; 2 envelope repairs
- `Kristal-Metrology` — kristal_state/6.0 via `v6_normalization`; 99 record-role mappings
- `Kristal-Physics` — kristal_state/6.0 via `v6_normalization`; 1 envelope repairs
- `Kristal-PoliceOps` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-Power` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-Recipes` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-ScolQc` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-Time` — kristal_state/6.0 via `v6_normalization`; 107 record-role mappings
- `Kristal-Transportation` — kristal_state/6.0 via `v6_normalization`; 2 envelope repairs
- `Kristal-VehiculeDiag` — structured_epistemic_state/5.0 via `structured_epistemic_state_to_v6`
- `Kristal-Work` — kristal_state/6.0 via `v6_normalization`; 2 envelope repairs
