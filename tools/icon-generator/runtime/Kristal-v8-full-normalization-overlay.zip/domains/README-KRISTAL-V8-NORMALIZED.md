# Kristal domains — v8 normalized

All 123 Kristal domain folders include a derived `.kristal/v8/` layer. Original files are preserved.

Start with `_catalog/V8_NORMALIZATION_REPORT.md`. Machine validation is in `_catalog/V8_NORMALIZATION_VALIDATION.json`.
