# Kristal v8 full static normalization overlay

Extract this archive over the parent directory that already contains `domains/`.
It only adds derived `.kristal/` metadata/artifacts and `desktop.ini`; it does not replace original semantic source files.

After extraction on Windows, run `Apply-Kristal-V8-Normalization.ps1` if you want Explorer folder icons/tooltips activated.

Validation: `domains/_catalog/V8_NORMALIZATION_VALIDATION.json`.
