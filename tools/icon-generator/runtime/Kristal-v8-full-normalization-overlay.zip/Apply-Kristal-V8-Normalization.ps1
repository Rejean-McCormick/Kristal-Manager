param([string]$DomainsRoot = (Join-Path $PSScriptRoot 'domains'))
$folders = Get-ChildItem -LiteralPath $DomainsRoot -Directory -Filter 'Kristal-*'
$ok = 0
foreach ($d in $folders) {
    $desktop = Join-Path $d.FullName 'desktop.ini'
    $kdir = Join-Path $d.FullName '.kristal'
    $v8 = Join-Path $kdir 'v8\portable-state.kristal-state.json'
    if ((Test-Path -LiteralPath $desktop) -and (Test-Path -LiteralPath $v8)) {
        attrib +r $d.FullName | Out-Null
        attrib +h +s $desktop | Out-Null
        attrib +h $kdir | Out-Null
        $ok++
    }
}
Write-Host "Kristal v8 normalization present on $ok/$($folders.Count) folders."
Write-Host 'The .kristal layer is derived/rebuildable; original source artifacts remain authoritative.'
